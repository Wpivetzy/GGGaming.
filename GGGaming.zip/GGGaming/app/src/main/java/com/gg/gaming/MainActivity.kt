package com.gg.gaming

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.navigation.compose.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GGTheme { GGApp(Store(applicationContext)) } }
    }
}

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()
fun appLabel(c: Context, pkg: String) = try { c.packageManager.getApplicationInfo(pkg, 0).loadLabel(c.packageManager).toString() } catch (e: Exception) { pkg }

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun GGApp(store: Store) {
    val nav = rememberNavController()
    val tabs = listOf(
        Tab("games", "Iniciar jogo", Icons.Default.PlayArrow), Tab("account", "Conta", Icons.Default.Person),
        Tab("lottery", "Loteria", Icons.Default.Casino), Tab("settings", "Config.", Icons.Default.Settings)
    )
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    Background {
        Scaffold(containerColor = Color.Transparent, bottomBar = {
            NavigationBar(containerColor = Color(0xCC1A0510)) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route, icon = { Icon(t.icon, null) }, label = { Text(t.label, fontSize = 11.sp) },
                        onClick = { nav.navigate(t.route) { popUpTo("games"); launchSingleTop = true } },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, indicatorColor = Orange, unselectedIconColor = Color.White.copy(.7f), selectedTextColor = Orange, unselectedTextColor = Color.White.copy(.7f))
                    )
                }
            }
        }) { pad ->
            NavHost(
                nav, "games", Modifier.padding(pad),
                enterTransition = { fadeIn() + slideInHorizontally { it / 6 } }, exitTransition = { fadeOut() },
                popEnterTransition = { fadeIn() }, popExitTransition = { fadeOut() + slideOutHorizontally { it / 6 } }
            ) {
                composable("games") { GamesScreen(store) }
                composable("account") { AccountScreen(store) }
                composable("lottery") { LotteryScreen() }
                composable("settings") { SettingsScreen(store) { nav.navigate(it) } }
                composable("permissions") { PermissionsScreen() }
                composable("mode") { ModeScreen(store) }
                composable("wireless") { WirelessScreen(store) }
            }
        }
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)

@Composable
fun GamesScreen(store: Store) {
    val ctx = LocalContext.current
    var picker by remember { mutableStateOf(false) }
    Page {
        Title("Jogos")
        GGButton("+ Adicionar jogo", Orange) { picker = true }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (store.games.isEmpty()) item { Text("Nenhum jogo adicionado ainda.", color = Color.White.copy(.8f)) }
            items(store.games) { pkg ->
                val sel = store.selected == pkg
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (sel) Green.copy(.35f) else Card)
                        .border(if (sel) 2.dp else 0.dp, Green, RoundedCornerShape(14.dp))
                        .clickable { store.select(pkg) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = remember(pkg) { try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() } catch (e: Exception) { null } }
                    if (icon != null) Image(icon, null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
                    else Icon(Icons.Default.SportsEsports, null, Modifier.size(56.dp), tint = Color.White)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(appLabel(ctx, pkg), color = Color.White, fontWeight = FontWeight.Bold)
                        Text(if (sel) "Selecionado" else pkg, color = Color.White.copy(.7f), fontSize = 12.sp)
                    }
                    IconButton({ store.removeGame(pkg); toast(ctx, "Jogo removido") }) { Icon(Icons.Default.Delete, "Remover", tint = Color.White) }
                }
            }
        }
        GGButton("Iniciar jogo", Green, store.selected != null) {
            val ok = Sys.launchGame(ctx, store.selected!!)
            toast(ctx, if (ok) "Iniciando jogo…" else "Erro: não foi possível abrir o jogo")
        }
    }
    if (picker) GamePicker(store) { picker = false }
}

@Composable
fun GamePicker(store: Store, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        ctx.packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName to it.loadLabel(ctx.packageManager).toString() }
            .distinct().sortedWith(compareByDescending<Pair<String, String>> { it.first == FF_MAX }.thenBy { it.second.lowercase() })
    }
    AlertDialog(
        onDismissRequest = onDismiss, confirmButton = { TextButton(onDismiss) { Text("Fechar") } },
        title = { Text("Escolha um app/jogo") }, containerColor = Wine,
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(apps) { (pkg, label) ->
                    Text(label, Modifier.fillMaxWidth().clickable { store.addGame(pkg); toast(ctx, "$label adicionado"); onDismiss() }.padding(12.dp), color = Color.White)
                }
            }
        }
    )
}

@Composable
fun AccountScreen(store: Store) {
    val ctx = LocalContext.current
    var n by remember { mutableStateOf(store.name) }
    Page {
        Title("Conta")
        Panel {
            OutlinedTextField(n, { n = it }, label = { Text("Nome de jogador") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            GGButton("Salvar") { store.setName(n.trim().ifEmpty { "Jogador" }); toast(ctx, "Conta salva") }
        }
    }
}

@Composable
fun LotteryScreen() {
    var nums by remember { mutableStateOf<List<Int>>(emptyList()) }
    Page {
        Title("Loteria")
        Panel {
            Text("Gere 6 números da sorte (1–60).", color = Color.White)
            Spacer(Modifier.height(10.dp))
            AnimatedContent(nums, label = "n") { l ->
                Text(if (l.isEmpty()) "—" else l.joinToString("  ") { "%02d".format(it) }, color = Orange, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
        }
        GGButton("Sortear", Orange) { nums = (1..60).shuffled().take(6).sorted() }
    }
}

@Composable
fun SettingsScreen(store: Store, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val ver = remember { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }
    Page {
        Title("Configurações")
        Panel { Text("Informações da Conta", color = Color.White, fontWeight = FontWeight.Bold); Text("Jogador: ${store.name}", color = Color.White.copy(.8f)) }
        Panel(onClick = { go("mode") }) { Text("Modo de Ativação", color = Color.White, fontWeight = FontWeight.Bold); Text(if (store.mode == "usb") "Com fio (USB/PC)" else "Sem fio (Wireless Debugging)", color = Color.White.copy(.8f)) }
        Panel(onClick = { go("wireless") }) { Text("Assistente de ativação", color = Color.White, fontWeight = FontWeight.Bold) }
        Panel(onClick = { go("permissions") }) { Text("Gerenciamento de permissões", color = Color.White, fontWeight = FontWeight.Bold) }
        Text("Versão do aplicativo: $ver", color = Color.White.copy(.7f))
    }
}

@Composable
fun ModeScreen(store: Store) {
    val ctx = LocalContext.current
    Page {
        Title("Modo de Ativação")
        listOf("usb" to "Com fio (USB/PC)", "wireless" to "Sem fio (Wireless Debugging)").forEach { (k, l) ->
            Panel(onClick = { store.setMode(k); toast(ctx, "Modo salvo") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(store.mode == k, { store.setMode(k); toast(ctx, "Modo salvo") }, colors = RadioButtonDefaults.colors(selectedColor = Green))
                    Text(l, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StatusRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) = Panel {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel, null, tint = if (ok) Green else Orange, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(12.dp))
        Text(title, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold)
        if (!ok) Button(onClick, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(action) }
    }
}

@Composable
fun PermissionsScreen() {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    key(tick) {
        Page {
            Title("Permissões")
            StatusRow("Janela flutuante", Sys.overlay(c), "Conceder") { if (!Sys.open(c, Sys.overlayIntent(c))) toast(c, "Erro ao abrir configurações") }
            StatusRow("Executar em segundo plano", Sys.ignoringBattery(c), "Permitir") { if (!Sys.open(c, Sys.batteryIntent(c))) toast(c, "Erro ao abrir configurações") }
            StatusRow("Economia de energia desativada", Sys.powerSaveOff(c), "Abrir") { Sys.open(c, Sys.powerSaverIntent()) }
            val all = Sys.overlay(c) && Sys.ignoringBattery(c) && Sys.powerSaveOff(c)
            Text(if (all) "✔ Todas as permissões concedidas" else "Conceda as permissões pendentes.", color = if (all) Green else Color.White)
        }
    }
}

@Composable
fun WirelessScreen(store: Store) {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    key(tick) {
        val dev = Sys.devOptions(c); val usb = Sys.usbDebug(c); val wifi = Sys.wifiDebug(c)
        val wireless = store.mode == "wireless"
        Page {
            Title(if (wireless) "Ativação sem fio" else "Ativação USB")
            StatusRow("1. Opções do desenvolvedor", dev, "Ativar") {
                toast(c, "Toque 7x em 'Número da versão'"); Sys.open(c, Sys.aboutIntent())
            }
            StatusRow("2. Depuração USB", usb, "Ativar") { if (!Sys.open(c, Sys.devIntent())) toast(c, "Ative as opções do desenvolvedor primeiro") }
            if (wireless) StatusRow("3. Depuração sem fio (porta aberta)", wifi, "Abrir") { if (!Sys.open(c, Sys.devIntent())) toast(c, "Erro ao abrir configurações") }
            else Panel { Text("3. Conecte o cabo USB ao PC e autorize a depuração no diálogo do Android.", color = Color.White) }
            val ready = dev && usb && (!wireless || wifi)
            Text(if (ready) "✔ Pronto para ativar" else "Conclua as etapas pendentes (status atualiza ao voltar).", color = if (ready) Green else Color.White)
            Spacer(Modifier.weight(1f))
            GGButton("ATIVAR", Green, ready) {
                val g = store.selected
                if (g == null) toast(c, "Erro: selecione um jogo na tela inicial")
                else toast(c, if (Sys.launchGame(c, g)) "Ativado com sucesso!" else "Erro ao iniciar o jogo")
            }
        }
    }
}
