package com.gg.gaming

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*

val Wine = Color(0xFF5A0F2E); val WineDark = Color(0xFF1A0510)
val Green = Color(0xFF22C55E); val Orange = Color(0xFFFF7A1A)
val Card = Color(0x33FFFFFF)

@Composable
fun GGTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Green, secondary = Orange, background = WineDark, surface = Wine, onSurface = Color.White),
    content = content
)

@Composable
fun Background(content: @Composable BoxScope.() -> Unit) = Box(
    Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, WineDark)))
) {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(Green.copy(alpha = .22f), 320f, Offset(size.width * .95f, size.height * .12f))
        drawCircle(Orange.copy(alpha = .20f), 260f, Offset(size.width * .05f, size.height * .55f))
        drawCircle(Green.copy(alpha = .12f), 420f, Offset(size.width * .8f, size.height * .92f))
    }
    content()
}

@Composable
fun Title(t: String) = Text(
    t, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.SansSerif,
    style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black, Offset(3f, 3f), 6f))
)

@Composable
fun GGButton(text: String, color: Color = Green, enabled: Boolean = true, onClick: () -> Unit) = Button(
    onClick, enabled = enabled, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().height(52.dp),
    colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White, disabledContainerColor = Color.Gray)
) { Text(text, fontWeight = FontWeight.Bold) }

@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) = Column(
    modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card)
        .let { if (onClick != null) it.clickable { onClick() } else it }.padding(16.dp), content = content
)
