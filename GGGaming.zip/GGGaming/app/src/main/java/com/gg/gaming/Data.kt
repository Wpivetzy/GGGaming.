package com.gg.gaming

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.*

const val FF_MAX = "com.dts.freefiremax"

class Store(c: Context) {
    private val p = c.getSharedPreferences("gg", Context.MODE_PRIVATE)
    var games by mutableStateOf(p.getString("games", "")!!.split(",").filter { it.isNotBlank() })
        private set
    var selected by mutableStateOf(p.getString("selected", null))
        private set
    var mode by mutableStateOf(p.getString("mode", "wireless")!!)
        private set
    var name by mutableStateOf(p.getString("name", "Jogador")!!)
        private set

    fun addGame(pkg: String) { if (pkg !in games) { games = games + pkg; p.edit().putString("games", games.joinToString(",")).apply() } }
    fun removeGame(pkg: String) {
        games = games - pkg; if (selected == pkg) select(null)
        p.edit().putString("games", games.joinToString(",")).apply()
    }
    fun select(pkg: String?) { selected = pkg; p.edit().putString("selected", pkg).apply() }
    fun setMode(m: String) { mode = m; p.edit().putString("mode", m).apply() }
    fun setName(n: String) { name = n; p.edit().putString("name", n).apply() }
}

object Sys {
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    fun ignoringBattery(c: Context) =
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
    fun powerSaveOff(c: Context) =
        !(c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
    fun devOptions(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
    fun usbDebug(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    fun wifiDebug(c: Context) = Settings.Global.getInt(c.contentResolver, "adb_wifi_enabled", 0) == 1

    fun open(c: Context, i: Intent): Boolean = try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    fun overlayIntent(c: Context) = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))
    fun batteryIntent(c: Context) = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))
    fun powerSaverIntent() = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
    fun aboutIntent() = Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
    fun devIntent() = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)

    fun launchGame(c: Context, pkg: String): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return open(c, i)
    }
}
